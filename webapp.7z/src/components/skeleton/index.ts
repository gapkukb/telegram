export { default } from './Skeleton.vue'
