const _keys = {
    app: 'app',
    locale: 'locale',
} as const

export type StorageKeys = EnumLike<typeof _keys>

export default _keys
