export enum ModalsName {
    guidelines = 'Guidelines',
    login = 'Login',
    otp = 'OTP',
    terms = 'Terms',
    captcha = 'captcha',
    locale = 'locale',
    cs = 'cs',
}
