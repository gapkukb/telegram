<script setup lang="ts">

</script>

<template>
    <div>
        Home header
    </div>
</template>

<style lang="scss" scoped>

</style>