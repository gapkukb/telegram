<script setup lang="ts">

</script>

<template>
    <div>
        for u
    </div>
</template>

<style lang="scss" scoped>

</style>