<script setup lang="ts">
import { useAsyncVisible } from '@/composables/useAsyncVisible'
</script>

<template>
    <ModalPage position="right" class="size-full">
        customer service
    </ModalPage>
</template>

<style lang="scss"></style>
