<script setup lang="ts">
import DashboardFooter from './DashboardFooter.vue'
import DashboardHeader from './DashboardHeader.vue'
</script>

<template>
    <DashboardHeader />
    <router-view />
    <DashboardFooter />
</template>

<style lang="scss">
.page-dashboard {
    --pb: 40px;
    --pt: 40px;
    padding-bottom: var(--pb);
    padding-top: var(--pt);
}
</style>
