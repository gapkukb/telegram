<script setup lang="ts">
import { Modals, ModalsName } from '@/modals'
import DashboardActions from './DashboardActions.vue'
import { useI18n } from 'vue-i18n'
import img0 from './assets/images/0.png'
import img1 from './assets/images/1.png'
import img2 from './assets/images/2.png'
import img3 from './assets/images/3.png'
import img4 from './assets/images/4.png'

const Foru = defineAsyncComponent(() => import('@/pages/foru/index.vue'))
const Slot = defineAsyncComponent(() => import('@/pages/slot/index.vue'))
const Fishing = defineAsyncComponent(() => import('@/pages/fishing/index.vue'))
const Poker = defineAsyncComponent(() => import('@/pages/poker/index.vue'))
const Casino = defineAsyncComponent(() => import('@/pages/casino/index.vue'))

const { t } = useI18n()
const active = ref(0)
const navs = [
    { name: t('foru'), icon: img0, id: 1, component: Foru },
    { name: t('slot'), icon: img1, id: 2, component: Slot },
    { name: t('fishing'), icon: img2, id: 3, component: Fishing },
    { name: t('poker'), icon: img3, id: 4, component: Poker },
    { name: t('casino'), icon: img4, id: 5, component: Casino },
]
</script>

<template>
    <header class="header fixed top-0 left-0 right-0">
        <div class="flex justify-between items-center h-40 px-12">
            <van-button round type="danger" size="small" @click="Modals.open(ModalsName.locale)">{{ $t('login') }}</van-button>
            <DashboardActions />
        </div>
        <van-tabs v-model:active="active" swipeable line-height="1">
            <van-tab v-for="item in navs" :key="item.id">
                <template #title>
                    <div class="inline-grid place-items-center gap-2">
                        <img :src="item.icon" class="size-20" />
                        <span class="text-12 lh-12">{{ item.name }}</span>
                    </div>
                </template>
                <component :is="item.component" />
            </van-tab>
        </van-tabs>
    </header>
</template>

<style lang="scss">
.header {
    height: var(--pt);
}
.van-tabs__line {
    background-color: #ff5800;
    &::before {
        content: '';
        border: 4px solid transparent;
        border-bottom-color: #ff5800;
        position: absolute;
        bottom: 0;
        left: 50%;
        translate: -50%;
    }
}
</style>
