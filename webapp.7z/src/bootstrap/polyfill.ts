Object.defineProperty(Promise, 'delay', {
    value(ms = 0) {
        if (ms === 0) return this.resolve()
        return new Promise((rs) => setTimeout(rs, ms))
    },
})

declare global {
    interface PromiseConstructor {
        delay(ms?: number): Promise<any>
    }
}
