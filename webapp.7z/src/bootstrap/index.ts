import "@/utils/fixFullHeight";
import "./polyfill"

export default async function bootstrap() {
  return;
}
