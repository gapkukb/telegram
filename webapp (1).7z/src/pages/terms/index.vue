<script setup lang="ts">

</script>

<template>
    <van-popup position="right">
        Terms
    </van-popup>
</template>

<style lang="scss" scoped>

</style>