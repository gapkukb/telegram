<script setup lang="ts">

</script>

<template>
    <div>
        Notification
    </div>
</template>

<style lang="scss" scoped>

</style>