<script setup lang="ts"></script>

<template>
    <input type="text">
    
</template>

<style lang="scss" scoped></style>
