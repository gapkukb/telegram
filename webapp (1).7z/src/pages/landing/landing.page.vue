<script setup lang="ts"></script>

<template>
  <div>Landing page</div>
</template>

