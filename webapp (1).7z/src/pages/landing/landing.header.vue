<script setup lang="ts">

</script>

<template>
    <div>
        landing header
    </div>
</template>
