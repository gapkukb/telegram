<script setup lang="ts"></script>

<template>
  <Back />
  <router-view />
</template>

<style lang="scss" ></style>
