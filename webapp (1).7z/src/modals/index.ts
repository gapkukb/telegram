export { ModalsName } from './ModalsName'
export { default as ModalsView } from './modalsView'
export { Modals } from './modals'
