import type { Router } from "vue-router";

/**
 * update html title description keywords
 */
export default function (router: Router): Router {
  return router;
}
