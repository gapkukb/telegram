import './style.scss'

export { default } from './Trigger.vue'
