<script setup lang="ts">
import { REGEXP_ACCOUNT } from '@/constants/regexp'
import type { FieldRule } from 'vant'
import { useI18n } from 'vue-i18n'

const value = defineModel<string>({ required: true })
const rules: FieldRule[] = [
    {
        pattern: REGEXP_ACCOUNT,
        message: useI18n().t('validator.account'),
    },
]
</script>

<template>
    <van-field
        v-model.trim="value"
        class="van-field-solid"
        :border="false"
        :placeholder="$t('placeholder.account')"
        :rules="rules"
    ></van-field>
</template>

<style lang="scss" scoped></style>
