declare module globalThis {
  var inApp: Readonly<boolean>;
}
