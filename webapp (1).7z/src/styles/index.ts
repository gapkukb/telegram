import "./reset.scss"
import "./vant.rewrite.css"
import "./boxed.scss"