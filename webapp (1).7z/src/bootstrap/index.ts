import "@/utils/fixFullHeight";
import "./polyfill"
import 'vant/lib/toast/style'

export default async function bootstrap() {
  return;
}
